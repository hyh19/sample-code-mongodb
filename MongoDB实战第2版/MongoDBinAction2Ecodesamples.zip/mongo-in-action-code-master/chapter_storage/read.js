c = db.benchmark.find();
while(c.hasNext()) c.next();
