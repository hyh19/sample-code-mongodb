DATABASE_HOST   = 'localhost'
DATABASE_PORT   = 27018
DATABASE_NAME   = "twitter-archive"
COLLECTION_NAME = "tweets"
TAGS = ["#MongoDB", "#Mongo"]

API_KEY             = "PrRlTUCxXUV7cUz8vCQ9cQ"
API_SECRET          = "ZBWEf7NtYrPzshwmyI2yx0YVUjtosXV1ujMUaPusTE"
ACCESS_TOKEN        = "420612447-tuKce4clrt3X1Q6rykxBrRFftA2jqMyHwa2nfNWc"
ACCESS_TOKEN_SECRET = "TCnPydNadJcoNkaujQed3kyZVsKkq1DfHkCkQ80C2lx6X"


