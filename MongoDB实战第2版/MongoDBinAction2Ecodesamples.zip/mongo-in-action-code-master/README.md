# mongo-in-action-code
This is the code for the 2nd edition of the MongoDB In Action book.

You can find more about the book at:
https://www.manning.com/books/mongodb-in-action-second-edition
