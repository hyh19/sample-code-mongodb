var MongoClient = require('mongodb').MongoClient;
var Server = require('mongodb').Server;
var mongo = new MongoClient();
var myDB = null;
mongo.connect("mongodb://localhost/", function(err, db) {
  myDB = db.db("words");
  myDB.collection("word_stats", function(err, collection){
    largeSmallVowels(collection);
    setTimeout(function(){myDB.close();}, 3000);
  });
});
function displayAggregate(results){
  for (var i in results){
    console.log(results[i]);
  }
}
function largeSmallVowels(collection){
  var match = {'$match' :
                {'first' :
                  {'$in' : ['a','e','i','o','u']}}};
  var group = {'$group' : 
                { '_id' : '$first', 
                  'largest' : {'$max' : '$size'},
                  'smallest' : {'$min' : '$size'},
                  'total' : {'$sum' : 1}}};
  var sort = {'$sort' : {'first' : 1}};
  collection.aggregate([match, group, sort], 
    function(err, results){
      console.log("\nLargest and smallest word sizes for " + 
                  "words beginning with a vowel");
      displayAggregate(results);
      top5AverageWordFirst(collection);
  });
}
function top5AverageWordFirst(collection){
  var group = {'$group' : 
                {'_id' : '$first', 
                 'average' : {'$avg' : '$size'}}};
  var sort = {'$sort' : {'average' : -1}};
  var limit = {'$limit' : 5};
  collection.aggregate([group, sort, limit], 
    function(err, results){
      console.log("\nFirst letter of top 5 largest average " + 
                  "word size: ");
      displayAggregate(results);
  });
}
